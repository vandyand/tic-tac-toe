
#!/bin/bash
open index.html
    