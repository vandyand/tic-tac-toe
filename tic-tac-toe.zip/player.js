
class Player {
constructor(mark, isHuman) {
this.mark = mark;
this.isHuman = isHuman;
}
}
    